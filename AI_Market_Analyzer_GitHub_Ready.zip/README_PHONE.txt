AI MARKET ANALYZER — GITHUB PHONE BUILD

1. Create a GitHub repository named AI-Market-Analyzer.
2. Extract this ZIP on your Android phone.
3. Upload ALL CONTENTS of this folder to the repository. Make sure the hidden .github/workflows/build-apk.yml file is uploaded too.
4. Commit the files to the main branch.
5. Open the repository -> Actions.
6. Tap "Build Android APK".
7. If it has not started, tap "Run workflow" -> "Run workflow".
8. Wait until the workflow has a green check.
9. Open the completed run.
10. Scroll to "Artifacts".
11. Tap "AI-Market-Analyzer-APK" to download it.
12. Extract that downloaded artifact ZIP.
13. Install app-debug.apk on Android.

The APK contains the live chart and analysis engine. It requires internet access for live Binance public market data.
